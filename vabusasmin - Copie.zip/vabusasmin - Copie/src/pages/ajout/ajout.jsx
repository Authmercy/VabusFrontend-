import React from "react";

import Header from "../../components/header/header";

import Ajout from "../../components/ajout/ajout";
const PageAjout = () => {
  return (
    <div>
      <Header />

      <Ajout />
    </div>
  );
};
export default PageAjout;
