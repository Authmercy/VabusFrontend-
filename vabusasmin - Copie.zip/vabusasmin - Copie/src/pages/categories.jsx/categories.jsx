import React from "react";

import Header from "../../components/header/header";

import Categories from "../../components/categories/categories";
const Pagecategories = () => {
  return (
    <div>
      <Header />

      <Categories />
    </div>
  );
};
export default Pagecategories;
