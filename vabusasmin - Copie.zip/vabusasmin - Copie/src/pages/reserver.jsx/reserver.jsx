import React from "react";

import Reserver from "../../components/reserver/reserver";
import Reservation from "../../components/reservation/reservation";
const PageReserver = () => {
  return (
    <div>
      <Reservation />
    </div>
  );
};
export default PageReserver;
