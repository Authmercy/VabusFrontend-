import React from "react";

import Header from "../../components/header/header";

import Edit from "../../components/edit/edit";
const PageEdit = () => {
  return (
    <div>
      <Header />

      <Edit />
    </div>
  );
};
export default PageEdit;
