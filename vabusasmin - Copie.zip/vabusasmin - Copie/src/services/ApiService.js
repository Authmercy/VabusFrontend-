import axios from "axios";

export  function getAgence() {
  return axios.get('http://127.0.0.1:8000/api/gestionreservation/reservationList')
  .then(res => {
    return res.data
  })}

  export  async function getreservation() {
    const res = await axios.get('http://127.0.0.1:8000/api/gestionAgences/agenceList');
      return res.data;}

export  async function ajout(Gestionagence) {
    const res = await axios.post('http://127.0.0.1:8000/api/gestionAgences/add_agence',
        {
            name: Gestionagence.name.value,
            picture: Gestionagence.picture.value,
            siege: Gestionagence.siege.value,
            telephone: Gestionagence.telephone.value,
            description: Gestionagence.description.value,
            published: Gestionagence.published.value,
        });
    return res.data;}

export  async function editagence(id, Gestionagence) {
    const res = await axios.put('http://127.0.0.1:8000/gestionAgences/<pk>/update_agence/' + id + '/',
        {
            name: Gestionagence.name.value,
            picture: Gestionagence.picture.value,
            siege: Gestionagence.siege.value,
            telephone: Gestionagence.telephone.value,
            description: Gestionagence.description.value,
            published: Gestionagence.published.value,
        });
    return res.data;}

export  async function agencedelete(name) {
    const res = await axios.delete('http://127.0.0.1:8000/gestionAgences/<pk>/delete_user/' + name + '/');
    return res.data;}