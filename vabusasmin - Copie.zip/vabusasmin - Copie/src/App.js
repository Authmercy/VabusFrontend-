import{ 
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom"


import Home from "./pages/Home/Home";

import PageAgence from "./pages/agence/agence";
import Pagecategories from "./pages/categories.jsx/categories";
import PageConnexion from "./pages/connexion.jsx/connexion";
import PageReserver from "./pages/reserver.jsx/reserver";
import PageInscription from "./pages/inscription.jsx/inscription";
import PageAjout from "./pages/ajout/ajout";
import PageEdit from "./pages/edit/edit";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<PageConnexion />} />
       
        <Route path="/agence" element={<PageAgence />} />
        <Route path="/categories" element={<Pagecategories />} />
        <Route path="/connexion" element={<Home/>} />
        <Route path="/home" element={<Home/>} />
        <Route path="/inscription" element={<PageInscription/>} />
        <Route path="/reservation" element={<PageReserver />} />
        <Route path="/ajout" element={<PageAjout />} />
        <Route path="/edit" element={<PageEdit/>} />
        </Routes>
    </BrowserRouter>
  );
}

export default App;

