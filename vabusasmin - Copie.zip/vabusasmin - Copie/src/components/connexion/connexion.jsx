import "./connexion.css";
import { getAgence } from "../../services/ApiService";

import  { useEffect, useState } from 'react'
import axios from "axios";
import { React, useRef } from 'react'
const Connexion = () => {
 
  const mailRef = useRef();
  const mdpRef = useRef();

  const handleSubmit2 = (event) => {
    event.preventDefault();
    let  Userloginform={};
    Userloginform.email = mailRef.current.value;
    Userloginform.password = mdpRef.current.value;

    const urlL = 'http://127.0.0.1:8000/api/gestionAuthentification/login';

    // const history = useHistory();
    console.log(Userloginform);
    axios.post(urlL, Userloginform)
    .then(response => {
      console.log(response);
      localStorage.setItem('userconnected', JSON.stringify(response.data));
      console.log(localStorage.getItem('userconnected'));
      window.location.href = '/';
    })
    .catch(error => {
      console.log(error);
    });    

  };
  return (

    <div>
    <div className="slogan">
      <a
        href="/"
        className="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none"
      >
        <span> Vabus</span>
      </a>
    </div>




    
    <div className="PartA">
      <div className="section">
        <div className="article">
          <div className="inscription">
            <h1>Connection</h1>
          </div>

          <div className="api">
            <div className="facebook">
              <i className="fab fa-facebook"></i>
              <span>FACEBOOK</span>
            </div>

            <div className="google">
              <i className="fab fa-google"></i>
              <span>GOOGLE</span>
            </div>

            <div className="apple">
              <i className="fab fa-apple"></i>
              <span>APPLE</span>
            </div>
          </div>

          <p className="choix">OU</p>

          <div className="titre2">
            <span> Connectez-vous avec votre adresse e-mail</span>
          </div>
 <form  onSubmit={handleSubmit2}>
          <div className="formulaire">
            <div classNameName="form">
              <div className="mail">
                <input
                  type="text"
                  placeholder="votre adresse mail"
                  name="email"
                  id="imail"ref={mailRef} 
                  required
                />
                <span id="spanmail"></span>
              </div>
              <div className="prenom">
                <input
                  type="text"
                  placeholder="mot de passe"
                  name="password"
                  id="password" ref={mdpRef} 
                />
                <span id="spanprenom"></span>
              </div>
            </div>

            <p className="soumission">
              <input type="submit" value="Se connecter" />
            </p>

            <p className="ouii" >
              <span>
                Vous n'avez pas de compte ?{" "}
                <a href="/inscription">Inscrivez vous !</a>
              </span>
            </p>
          </div></form>
        </div>
      </div>
    </div>
    </div>
  );
};
export default Connexion;