import React from "react";
import "./ajout.css";
import { getAgence } from "../../services/ApiService";


import  { useEffect, useState , useRef} from 'react'
import axios from "axios";

const Ajout = () => {
 
    const  nameRef  = useRef();
    const  pictureRef = useRef();
    const siegeRef = useRef();
    const  telephoneRef = useRef();
    const descriptionRef = useRef();
    
    let [Gestionagence, setGestionagence]=useState({
      name :'',
      picture :'',
      siege:'',
      telephone:'',
      description:'',
   
    });



  const handlesubmit = (event) => {
    event.preventDefault();
  
    Gestionagence.name = nameRef.current.value;;
    Gestionagence.picture = pictureRef.current.value;;
    Gestionagence.siege = siegeRef.current.value;;
    Gestionagence.telephone = telephoneRef.current.value;;
    Gestionagence.description = descriptionRef.current.value;;
    
    const url = 'http://127.0.0.1:8000/api/gestionAgences/add_agence/';

    console.log(Gestionagence);
    axios.post(url,Gestionagence)
      .then(response => {
        console.log(response);
      })
      .catch(error => {
        console.log(error);
      });
  };




  return (
    <div className="PartA">
    <div className="section">
      <div className="article">
    <div className="formulaire">
    <form action="#" onSubmit={handlesubmit}  method="POST" >
            <div className="form" >
            <div className="nom">
                <input
                  type="text"
                  placeholder="votre nom"
                  name="nom"
                  id="name" 
                  ref={nameRef}
                  
                />
                <span id="spannom"></span>
              </div>

              <div className="prenom">
                <input
                  type="file"
                  ref={pictureRef}
                  
                  name="picture"

                 
                />
                <span id="spanprenom"></span>
              </div>

              <div className="mail">
                <input
                  type="text"
                  placeholder="votre siege"
                  name="siege"
                  id="imail"
                  ref={siegeRef}
                  required
                />
                <span id="spanmail"></span>
              </div>
              <div className="motdepasse">
                <input
                  type="telephone"
             
                  placeholder="votre mot de passe"
                  name="telephone"
                  id="mdp"
                  ref={telephoneRef}
               
                  required
                />
                <span id="spanmdp"></span>
              </div>

             
              <div className="conmotdepasse">
                <input
                  type="textfield"
                  placeholder="Description"
                  name="description"
                  id="cmdp"
                  ref={descriptionRef}
              
                  required
                />
                <span id="spanmdp"></span>
              </div>
              <span className="verif"> </span>
            </div>
              
            <button type="submit" class="btn  btn-success md-5">  Upload </button>
      <a href="/" class="btn btn-danger ">Cancel</a>

        </form>
        </div>
        
  
          </div>
          
    
        </div>
        
      </div>

  );
};

export default Ajout;