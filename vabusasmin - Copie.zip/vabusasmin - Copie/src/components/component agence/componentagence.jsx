import React from "react";
import "./agence.css";
import bus1 from "../../img/bus2.jpeg";
import { ajout, editagence , agencedelete} from '../../services/ApiService'
import { getAgence } from "../../services/ApiService";
import  { useEffect, useState } from 'react'





export default function ComponentAgence(){
const [Gestionagence, setAgence]=useState([])
const [showAddAgenceForm, setShowAddAgenceForm] = useState(false)
const [showEditAgenceForm, setShowEditAgenceForm] = useState(false)
const [selectedEditData, setSelectedEditData] = useState()


useEffect(() => {
  let mount = true
  getAgence()
  .then(res => {console.log("res from api", res)
      setAgence(res)
      return() => mount = false
  })
}, []);

const handlesubmit = (e) => {
  ajout(e.target)
  .then(res => {
      setAgence(res)
  })
}

const handleEditBtn = (agence ) => {
  setSelectedEditData(agence )
  console.log("agence selected is", agence)
  setShowEditAgenceForm(true)
  setShowAddAgenceForm(false)
}

const handleEditSubmit = (e, id) => {
  editagence(id, e.target)
  .then(res => {
      setAgence(res)
  })
}

function handleCancelBtn() {
  setShowAddAgenceForm(false)
}
const handleDeleteBtn = (id) => {
   agencedelete(id)
  .then(res => {
      setAgence(Gestionagence.filter(p=> p.name!== id))
  })
}


return (
  
<div>
<nav aria-label="breadcrumb">

      { Gestionagence?.results?.map(item => (
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/">Home</a></li>

 
         
           
          <li className="breadcrumb-item active" aria-current="page">
          {item.name}
          </li>
        </ol>
      ))}
   </nav>
   { Gestionagence?.results?.map(item => (
      <div className="row">
        <div className="col-12 col-md-4"> 
          <img
            src={item.picture}
            className="img-fluid sticky-top"
            alt={item.name}
            loading="lazy"
          />
        </div>

        <div className="col-12 col-md-8">
          <div className="row">
            <div className="col-12">
              <h1>{item.name} </h1>
              <br />
              <p style={{ margin: "15PX;" }}>
              {item.description}
              </p>
              <div className="prix" style={{ display: "flex" }}>
                <div className="card-columns;">
                  <div className="card" style={{ width: " 18em;" }}>
                    <div className="card-body">
                      <h5 className="card-title">
                        <strong> Yaounde - Douala </strong>
                      </h5>
                      <br />
                      8000
                      <br />
                      <a href="/reserver" className="btn btn-warning">
                        Reserver
                      </a>
                    </div>
                  </div>
                </div>

                <div className="card-columns">
                  <div className="card" style={{ width: "18em;" }}>
                    <div className="card-body">
                      <h5 className="card-title">
                        <strong> Yaounde - Douala</strong>
                      </h5>
                      <br />
                      8000
                      <br />
                      <a href="/reserver" className="btn btn-warning">
                        Reserver
                      </a>
                    </div>
                  </div>
                </div>
                <div className="card-columns">
                  <div className="card" style={{ width: "18em;" }}>
                    <div className="card-body">
                      <h5 className="card-title">
                        <strong> Yaounde - Douala</strong>
                      </h5>
                      <br />
                      8000 <br />
                      <a href="/reserver" className="btn btn-warning">
                        f Reserver
                      </a>
                    </div>
                  </div>
                </div>
                <div className="card-columns">
                  <div className="card" style={{ width: "18em" }}>
                    <div className="card-body">
                      <h5 className="card-title">
                        <strong> Yaounde - Douala</strong>
                      </h5>
                      <br />
                      8000
                      <br />
                      <a href="/reserver" className="btn btn-warning">
                        Reserver
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row pt-4">
          <div className="col-12">
            <h4>Commentaire</h4>
            Tres belle agence
          </div>
        </div>
        </div>
          
          ))}
        </div>
        
        
      );
   }
