import React from "react";
import "./hearder.css";
import { ajout} from '../../services/ApiService'
import { getAgence } from "../../services/ApiService";
import  { useEffect, useState } from 'react'



const Header = () => {

  const [Gestionagence, setGestionagence]=useState([])
  const [showAddGestionagenceForm, setShowAddGestionagenceForm] = useState(false)
  const [showEditGestionagenceForm, setShowEditGestionagenceForm] = useState(false)
  const [selectedEditData, setSelectedEditData] = useState()
  


const handlesubmit = (e) => {
  ajout(e.target)
  .then(res => {
      setGestionagence(res)
  })
}
 useEffect(() => {
  let mount = true
  getAgence()
  .then(res => {console.log("res from api", res)
      setGestionagence(res)
      return() => mount = false
  })
}, []);
    

  return (
    <div className="container-xxl px-md-5 bg-white shadow-lg">
      <header className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
        <div className="slogan">
          <a
            href="/"
            className="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none"
          >
            <span> VabusAdmin</span>
          </a>
        </div>

        <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
          <li>
            <a href="/home" className="nav-link px-2 link-secondary">
              Accueil
            </a>
          </li>
          <li>
            <a href="/ajout" className="nav-link px-2 link-secondary">
         Ajouter une Agence
            </a>
          </li>
          <li>
            <a href="/reservation"  className="nav-link px-2 link-secondary">
         Liste de reservation
            </a>
          </li>
          <li>
          
          </li>
        </ul>

        <div className="col-md-3 text-end">
          <form method="POST" action="/search">
            <input
              type="search"
              name="searchTerm"
              className="form-control"
              placeholder="Search..."
              aria-label="Search"
            />
          </form>
        </div>
      </header>
    </div>
  );
};
export default Header;
