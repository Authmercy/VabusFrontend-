import React from "react";

import "./agence.css";
import bus1 from "../../img/bus2.jpeg";
import { ajout, editagence , agencedelete} from '../../services/ApiService'
import { getreservation } from "../../services/ApiService";
import  { useEffect, useState } from 'react'





class Reservation extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      Reservation: []
    };
  }

componentDidMount() {
    fetch("http://127.0.0.1:8000/api/gestionreservation/reservationList")
      .then(res => res.json())
      .then(
        (result) => {
          console.log(result);
          this.setState({
            isLoaded: true,
            Reservation: result
          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }


render() {
  const { error, isLoaded, Reservation } = this.state;
  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (!isLoaded) {
    return <div>Loading...</div>;
  } else {
    return (
        <div>
              <section class="pb-4 pt-4">
          LISTE DE RESERVATION
          
          <div className="row row-cols-2 row-cols-lg-5 g-2 g-lg-3">
          {Reservation?.results?.map(item => (
            <li key={item.id}>
              <div className="pt-1">{item.user}</div>
            
               <div className="pt-1">{item.depart}</div>
               <div className="pt-1">{item.destination}</div>
               <div className="pt-1">{item.datedepart}</div>
               <div className="pt-1">{item.qte}</div>
               <div className="pt-1">{item.agence}</div>
           
           <center>
                    
                    <a href=" delete/{{gestionagence.id}}" class="btn btn-danger" id=" {{gestionagence.id}} ">Delete </a>
                </center> 
           </li>
          ))}
        </div>
        </section>
           </div>
      );
    }

  
  }
}

export default Reservation;