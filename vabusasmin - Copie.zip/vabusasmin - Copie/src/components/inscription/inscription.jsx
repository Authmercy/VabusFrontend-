import React from "react";
import "./inscription.css";
import  { useEffect, useState , useRef} from 'react'
import axios from "axios";

const Inscription = () => {


  const nomRef = useRef();
  const emailRef = useRef();
  const mdp1Ref = useRef();

  const mailRef = useRef();
  const mdpRef = useRef();

  const handleSubmit = (event) => {
  event.preventDefault();
  let  UserRegisterform={};
  UserRegisterform.username = nomRef.current.value;
  UserRegisterform.email = emailRef.current.value;
  UserRegisterform.password = mdp1Ref.current.value;

  // UserRegisterform.password2 = mdp2Ref.current.value;
  const urlR = 'http://127.0.0.1:8000/api/gestionAuthentification/register';
  console.log(UserRegisterform);
  axios.post(urlR, UserRegisterform)
    .then(response => {
      console.log(response);
  
    })
    .catch(error => {
      console.log(error);
    });
    
  };

  return (
    <div>
    <div className="slogan">
      <a
        href="/"
        className="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none"
      >
        <span> Vabus</span>
      </a>
    </div>
    <div className="PartA">
      <div className="section">
        <div className="article">
          <div className="inscription">
            <h1>Inscription</h1>
          </div>

          <div className="api">
            <div className="facebook">
              <i className="fab fa-facebook"></i>
              <span>FACEBOOK</span>
            </div>

            <div className="google">
              <i className="fab fa-google"></i>
              <span>GOOGLE</span>
            </div>

            <div className="apple">
              <i className="fab fa-apple"></i>
              <span>APPLE</span>
            </div>
          </div>

          <p className="choix">OU</p>

          <div className="titre2">
            <span>Inscrivez-vous avec votre adresse e-mail</span>
          </div>

          <div className="formulaire">
          </div>
 <form  onSubmit={handleSubmit} method="POST" action="traitement.php">
          <div className="formulaire">
            <div className="form"  >
              <div className="nom">
                <input
                  type="text"
                  placeholder="votre nom"
                  name="firstname"
                  id="name"
                  ref={nomRef}
                />
                <span id="spannom"></span>
              </div>

             
               

              <div className="mail">
                <input
                  type="text"
                  placeholder="votre adresse mail"
                  name="email"
                  id="imail"
                  ref={emailRef}
                  required
                />
                <span id="spanmail"></span>
              </div>
              <div className="motdepasse">
                <input
                  type="password"
                  placeholder="votre mot de passe"
                  name="password1"
                  id="mdp"
                  ref={mdp1Ref}
                  required
                />
                <span id="spanmdp"></span>
              </div>

              <div className="conmotdepasse">
                <input
                  type="password"
                  placeholder="confirmer le mot de passe"
                  name="password1"
                  id="cmdp"
                  ref={mdpRef}
                  required
                />
                <span id="spanmdp"></span>
              </div>
              <span className="verif"> </span>
            </div>

            <div className="condition">
              <p className="con-utilisation1">
                <input type="checkbox" name="" id="check" required /> J'ai lu et
                j'accepte les <a href="#">conditions generales d'utilisation</a>{" "}
                et de{" "}
                <a href="">
                  la politique de protection des donnees personelles
                </a>
              </p>

              <p className="soumission">
               <button type="submit" class="btn  btn-success md-5"> S'inscrire </button>
              </p>

              <p className="ouii">
                <span>
                  Vous avez deja un compte ?{" "}
                  <a href="/connexion">Connecter vous !</a>
                </span>
              </p>
            </div>
          </div></form>
        </div>
      </div>
    </div>
    </div>
  );
};
export default Inscription;

