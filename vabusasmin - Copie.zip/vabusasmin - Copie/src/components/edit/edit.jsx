import React from 'react'

import "./ajout.css";
import { getAgence } from "../../services/ApiService";

import  { useEffect, useState } from 'react'
import axios from "axios";

export default function Edit({handleEditSubmit, selectedEditData})
 {
  const [Gestionagence, setGestionagence]=useState({
    name:'',
   description:'',
   siege :'',
   telephone:'',
   picture:''

});

const handleChange = (event) => {
  setGestionagence({
    Gestionagence,
    [event.target.name]: event.target.value
  });
};
  return (
   
    <><h3>EDIT FORM:</h3><div className="PartA">
      <div className="section">
        <div className="article">
          <div className="formulaire">
            <form onSubmit={(e) => handleEditSubmit(e, selectedEditData.name)}>
              <div className="form">
                <div className="nom">
                  <input
                    type="text"
                    placeholder="votre nom"
                    name="nom"
                    id="name" 
                    value={Gestionagence.name} />
                  <span id="spannom"></span>
                </div>

                <div className="prenom">
                  <input
                    type="file"
                    
                    value={Gestionagence.picture}
                    name="picture" />
                  <span id="spanprenom"></span>
                </div>

                <div className="mail">
                  <input
                    type="text"
                    placeholder="votre siege"
                    name="siege"
                    id="imail"
                  
                    value={Gestionagence.siege}
                    required />
                  <span id="spanmail"></span>
                </div>
                <div className="motdepasse">
                  <input
                    type="telephone"
                   
                    placeholder="votre mot de passe"
                    name="telephone"
                    id="mdp"
                    value={Gestionagence.telephone}
                    required />
                  <span id="spanmdp"></span>
                </div>


                <div className="conmotdepasse">
                  <input
                    type="textfield"
                    placeholder="Description"
                    name="description"
                    id="cmdp"
                 
                    value={Gestionagence.description}
                    required />
                  <span id="spanmdp"></span>
                </div>
                <span className="verif"> </span>
              </div>
              <button type='submit'>EDIT</button>
            </form>
          </div>


        </div>


      </div>

    </div></>
 );
};